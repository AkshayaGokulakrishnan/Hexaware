<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practice Tests</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('images/bg3.jpeg');
            background-size: cover;
            background-position: center;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }
        .container {
            width: 80%;
            max-width: 800px; 
            background: rgba(0, 0, 0, 0.7); 
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.5);
            margin-bottom: 20px; 
        }
        .header {
            background: rgba(0, 0, 0, 0.8); 
            color: #fff;
            padding: 20px 0;
            text-align: center;
            border-radius: 10px 10px 0 0;
        }
        .header h1 {
            margin: 0;
        }
        .search-filter {
            margin: 20px 0;
            text-align: center;
        }
        .search-filter input,
        .search-filter select {
            padding: 10px;
            margin: 5px;
            border-radius: 5px;
            border: 1px solid #ddd;
            width: 200px;
            background: #333; 
            color: #fff;
        }
        .search-filter input::placeholder,
        .search-filter select {
            color: #bbb; 
        }
        .test-list {
            list-style-type: none;
            padding: 0;
        }
        .test-item {
            background: rgba(255, 255, 255, 0.9); 
            color: #333; 
            margin: 10px 0;
            padding: 15px;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
        }
        .test-item span {
            color: #007bff; 
            font-weight: bold;
        }
        .test-item button {
            background: #28a745;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        .test-item button:hover {
            background: #218838;
        }
        .home-button {
            background: #007bff; 
            color: #fff;
            border: none;
            padding: 15px 30px;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
        }
        .home-button:hover {
            background: #0056b3; 
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Practice Tests</h1>
        </div>
        <div class="search-filter">
            <input type="text" placeholder="Search tests...">
            <select>
                <option value="">All Types</option>
                <option value="vocabulary">Vocabulary</option>
                <option value="speech">Speech</option>
                <option value="pronunciation">Pronunciation</option>
            </select>
        </div>
        <ul class="test-list">
            <li class="test-item">
                <span>Test 1: Vocabulary Basics</span>
                <button onclick="startTest('vocabulary')">Start Test</button>
            </li>
            <li class="test-item">
                <span>Test 2: Advanced Speech</span>
                <button onclick="startTest('speech')">Start Test</button>
            </li>
            <li class="test-item">
                <span>Test 3: Pronunciation Drills</span>
                <button onclick="startTest('pronunciation')">Start Test</button>
            </li>
        </ul>
    </div>
    <a href="http://localhost/hexass/home.php" class="home-button">Home</a>

    <script>
        function startTest(testType) {
            window.location.href = `test.html?test=${testType}`;
        }
    </script>
</body>
</html>
