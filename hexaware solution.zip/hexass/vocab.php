<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vocabulary Lessons</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-image: url('images/bg3.jpeg');
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #fff;
        }

        .lessons-container {
            width: 90%;
            max-width: 800px;
            background-color: rgba(0, 0, 0, 0.7);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 26px;
            color: #f8c471;
            letter-spacing: 2px;
        }

        .level-selection {
            margin-bottom: 25px;
            text-align: center;
        }

        .level-selection button {
            padding: 10px 20px;
            margin: 5px;
            background-color: #f39c12;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
            font-weight: bold;
        }

        .level-selection button:hover {
            background-color: #e67e22;
            transform: scale(1.05);
        }

        .lesson-list {
            display: none;
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .lesson-list.active {
            display: block;
        }

        .lesson-list li {
            margin-bottom: 15px;
            padding: 15px;
            background-color: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: background 0.3s ease;
        }

        .lesson-list li:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .lesson-title {
            font-size: 18px;
            color: #f8c471;
            flex: 1;
        }

        .start-button {
            padding: 10px 20px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
        }

        .start-button:hover {
            background-color: #2980b9;
            transform: scale(1.05);
        }

        .lesson-buttons {
            margin-top: 20px;
            display: none;
        }

        .lesson-buttons.active {
            display: block;
            text-align: center;
        }

        .lesson-buttons button {
            margin: 10px;
            padding: 10px 25px;
            background-color: #2ecc71;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
            font-weight: bold;
        }

        .lesson-buttons button:last-child {
            background-color: #e74c3c;
        }

        .lesson-buttons button:hover {
            opacity: 0.9;
            transform: scale(1.05);
        }

        .home-button {
            margin-top: 30px;
            text-align: center;
        }

        .home-button a {
            padding: 10px 20px;
            background-color: #f39c12;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s ease, transform 0.3s ease;
            font-weight: bold;
        }

        .home-button a:hover {
            background-color: #e67e22;
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <div class="lessons-container">
        <h1>Vocabulary Lessons</h1>

        
        <div class="level-selection">
            <button onclick="showLessons('beginner')">Beginner</button>
            <button onclick="showLessons('intermediate')">Intermediate</button>
            <button onclick="showLessons('advanced')">Advanced</button>
        </div>

        
        <ul class="lesson-list" id="beginner">
            <li>
                <div class="lesson-title">Basic Vocabulary Building</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/8QqF0QKcq6M', 'https://www.learnenglish.de/wordlist/pdf/Basic_Vocabulary.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Everyday Vocabulary</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/XJcOfL7ytN8', 'https://www.englishclub.com/vocabulary/pdf/everyday-vocabulary.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Common Phrases</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/5Vd6b4Yuqcw', 'https://www.efset.org/pdf/common-phrases.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Pronunciation Basics</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/3t9W4g8t8Zs', 'https://www.americanenglish.state.gov/sites/default/files/2020-03/PronunciationBasics.pdf')">Start Lesson</button>
            </li>
        </ul>

        <ul class="lesson-list" id="intermediate">
            <li>
                <div class="lesson-title">Advanced Vocabulary Usage</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/s0rEYjEz7Aw', 'https://www.vocabulary.com/advanced_usage.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Vocabulary in Context</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/0x29f_F9bI8', 'https://www.contextualvocabulary.com/usage.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Synonyms and Antonyms</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/Rk6XHbmtj7k', 'https://www.synonymsantonymsguide.com/vocabulary.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Idiomatic Expressions</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/2pqU9TY8j-I', 'https://www.idiomaticexpressions.com/idioms.pdf')">Start Lesson</button>
            </li>
        </ul>

        <ul class="lesson-list" id="advanced">
            <li>
                <div class="lesson-title">Specialized Vocabulary</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/Se6okY5ElxU', 'https://www.specializedvocabulary.com/advanced.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Vocabulary for Academic Writing</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/9ttzx8tu5Jk', 'https://www.academicvocabulary.com/writing.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Using Advanced Vocabulary</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/2Mxu6ckpVj8', 'https://www.advancedvocabularyguide.com/usage.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Vocabulary for Professional Contexts</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/Mv-Q_xb-yTo', 'https://www.professionalvocabulary.com/context.pdf')">Start Lesson</button>
            </li>
        </ul>

        
        <div id="lesson-buttons" class="lesson-buttons">
            <button id="videoButton" onclick="openLink('')">Watch Video</button>
            <button id="pdfButton" onclick="openLink('')">Read PDF</button>
        </div>

        
        <div class="home-button">
            <a href="http://localhost/hexass/home.php" onclick="goHome()">Back to Home</a>
        </div>
    </div>

    <script>
        function showLessons(level) {
            document.querySelectorAll('.lesson-list').forEach(function(list) {
                list.classList.remove('active');
            });

            document.getElementById(level).classList.add('active');

            document.getElementById('lesson-buttons').classList.remove('active');
        }

        function showLessonOptions(videoLink, pdfLink) {
            document.getElementById('lesson-buttons').classList.add('active');
            document.getElementById('videoButton').setAttribute('onclick', 'openLink("' + videoLink + '")');
            document.getElementById('pdfButton').setAttribute('onclick', 'openLink("' + pdfLink + '")');
        }

        function openLink(link) {
            window.open(link, '_blank');
        }

        function goHome() {
            document.querySelectorAll('.lesson-list').forEach(function(list) {
                list.classList.remove('active');
            });

            document.getElementById('lesson-buttons').classList.remove('active');
        }
    </script>
</body>
</html>
