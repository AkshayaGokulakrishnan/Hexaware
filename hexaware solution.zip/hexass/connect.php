<?php
$a=$_POST['fullname'];
$b=$_POST['email'];
$c=$_POST['password'];
$d=$_POST['confirmpsd'];
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con,'hexass');
$sql=("insert into registration (fullname,email,password,confirmpsd) values ('$a','$b','$c','$d')");
mysqli_query($con,$sql);
echo('<script>');
echo('alert("registered successfully")');
echo('</script>');
include ('register.php');
mysqli_close($con);
?>
