<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Speech Lessons</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-image: url('images/bg3.jpeg');
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #fff;
        }

        .lessons-container {
            width: 90%;
            max-width: 800px;
            background-color: rgba(0, 0, 0, 0.7);
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 26px;
            color: #f8c471;
            letter-spacing: 2px;
        }

        .level-selection {
            margin-bottom: 25px;
            text-align: center;
        }

        .level-selection button {
            padding: 10px 20px;
            margin: 5px;
            background-color: #f39c12;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
            font-weight: bold;
        }

        .level-selection button:hover {
            background-color: #e67e22;
            transform: scale(1.05);
        }

        .lesson-list {
            display: none;
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .lesson-list.active {
            display: block;
        }

        .lesson-list li {
            margin-bottom: 15px;
            padding: 15px;
            background-color: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: background 0.3s ease;
        }

        .lesson-list li:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .lesson-title {
            font-size: 18px;
            color: #f8c471;
            flex: 1;
        }

        .start-button {
            padding: 10px 20px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
        }

        .start-button:hover {
            background-color: #2980b9;
            transform: scale(1.05);
        }

        .lesson-buttons {
            margin-top: 20px;
            display: none;
        }

        .lesson-buttons.active {
            display: block;
            text-align: center;
        }

        .lesson-buttons button {
            margin: 10px;
            padding: 10px 25px;
            background-color: #2ecc71;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
            font-weight: bold;
        }

        .lesson-buttons button:last-child {
            background-color: #e74c3c;
        }

        .lesson-buttons button:hover {
            opacity: 0.9;
            transform: scale(1.05);
        }

        .home-button {
            margin-top: 30px;
            text-align: center;
        }

        .home-button a {
            padding: 10px 20px;
            background-color: #f39c12;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s ease, transform 0.3s ease;
            font-weight: bold;
        }

        .home-button a:hover {
            background-color: #e67e22;
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <div class="lessons-container">
        <h1>Speech Lessons</h1>

        
        <div class="level-selection">
            <button onclick="showLessons('beginner')">Beginner</button>
            <button onclick="showLessons('intermediate')">Intermediate</button>
            <button onclick="showLessons('advanced')">Advanced</button>
        </div>

        
        <ul class="lesson-list" id="beginner">
            <li>
                <div class="lesson-title">Speech Structure Basics</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/hN7vsXAUCgk?si=VCucXS-A5WemLMFC', 'http://www.lrjj.cn/encrm1.0/public/upload/Speech%20Structure-%23Handout%23.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Overcoming Nervousness</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/83wYDzO3CzI?si=kmf3ZIjYhibqqFR4', 'https://www.mentalhealth.org.uk/sites/default/files/2022-07/MHF-How-to-overcome-fear-and-anxiety.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Effective Eye Contact</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/8OGDhlUvSK4?si=sm_ZdSuEd7iYtZaF', 'https://www.researchgate.net/publication/268802880_Eye_Contact_as_an_Efficient_Non-verbal_Teaching_Technique_A_Survey_of_Teachers_Opinion')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Using Gestures</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/cFLjudWTuGQ?si=5oUAv1gDFkmHfP1l', 'https://www.researchgate.net/publication/258255456_Learning_through_gesture')">Start Lesson</button>
            </li>
        </ul>

        <ul class="lesson-list" id="intermediate">
            <li>
                <div class="lesson-title">Mastering Voice Modulation</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/RyuuA6aiQfQ?si=h_etC3jFznm3XtC0', 'https://rahulbhatnagar.com/wp-content/uploads/2018/05/Voice-Modulation.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Advanced Speech Structure</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/eplQBhE0-Hg?si=-mowdsdB6isUGhjp', 'http://repository.uinsu.ac.id/8533/1/ADVANCED%20SPEAKING.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Engaging the Audience</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/Ns_z4wEtdRM?si=DyvRfJPdgUlOXpzX', 'https://www.researchgate.net/publication/332750171_Audience_Engagement')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Storytelling Techniques</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/yHcak_7E1rQ?si=AHmYJBfC38h-X7sP', 'https://scert.assam.gov.in/sites/default/files/swf_utility_folder/departments/scert_medhassu_in_oid_6/portlet/level_2/EE05_V2_0.pdf')">Start Lesson</button>
            </li>
        </ul>

        <ul class="lesson-list" id="advanced">
            <li>
                <div class="lesson-title">Persuasive Speaking</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/jnfoFN7TBhw?si=KP2CbWGQ7nt5yahj', 'https://www.toastmasters.org.nz/wp-content/uploads/2021/12/8308-Persuasive-Speaking.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Mastering Rhetoric</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/EoXqVJnISWg?si=CngG8IssBZND9dm1', 'https://www.joycerain.com/uploads/2/3/2/0/23207256/essential_guide_to_rhetoric.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Speech Analysis Techniques</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/hi6i8cwfE68?si=sE2pFb3WdJCuN4wh', 'https://www.asel.udel.edu/speech/cis889/Analysis.pdf')">Start Lesson</button>
            </li>
            <li>
                <div class="lesson-title">Debating Skills</div>
                <button class="start-button" onclick="showLessonOptions('https://youtu.be/F84Y0jQwG0w?si=NBzSEH5qo35-pozh', 'https://www.debatingsa.com.au/wp-content/uploads/2014/03/Debating-A-Brief-Introduction-for-Beginners.pdf')">Start Lesson</button>
            </li>
        </ul>

        
        <div id="lesson-buttons" class="lesson-buttons">
            <button id="videoButton" onclick="openLink('')">Watch Video</button>
            <button id="pdfButton" onclick="openLink('')">Read PDF</button>
        </div>

        
        <div class="home-button">
            <a href="http://localhost/hexass/home.php" onclick="goHome()">Back to Home</a>
        </div>
    </div>

    <script>
        function showLessons(level) {
            document.querySelectorAll('.lesson-list').forEach(function(list) {
                list.classList.remove('active');
            });

            document.getElementById(level).classList.add('active');

            document.getElementById('lesson-buttons').classList.remove('active');
        }

        function showLessonOptions(videoLink, pdfLink) {
            document.getElementById('lesson-buttons').classList.add('active');
            document.getElementById('videoButton').setAttribute('onclick', 'openLink("' + videoLink + '")');
            document.getElementById('pdfButton').setAttribute('onclick', 'openLink("' + pdfLink + '")');
        }

        function openLink(link) {
            window.open(link, '_blank');
        }

        function goHome() {
            document.querySelectorAll('.lesson-list').forEach(function(list) {
                list.classList.remove('active');
            });

            document.getElementById('lesson-buttons').classList.remove('active');
        }
    </script>
</body>
</html>
