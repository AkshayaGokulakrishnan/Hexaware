<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url(images/bg3.jpeg);
            background-repeat: no-repeat;
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .dashboard-container {
            width: 90%;
            max-width: 1200px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            display: flex;
        }

        .navigation-menu {
            width: 20%;
            background-color: #2c3e50;
            padding: 20px;
            box-sizing: border-box;
        }

        .navigation-menu ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .navigation-menu ul li {
            margin-bottom: 15px;
        }

        .navigation-menu ul li a {
            text-decoration: none;
            color: #ecf0f1;
            font-size: 16px;
            display: block;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background 0.3s ease;
        }

        .navigation-menu ul li a:hover {
            background-color: #34495e;
        }

        .main-content {
            width: 80%;
            padding: 40px;
            box-sizing: border-box;
        }

        .welcome-message h1 {
            margin-top: 0;
            color: #34495e;
        }

        .quick-access h2 {
            color: #34495e;
            margin-bottom: 20px;
        }

        .quick-access-buttons {
            display: flex;
            gap: 20px;
        }

        .quick-access-buttons button {
            flex: 1;
            padding: 15px;
            font-size: 16px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .quick-access-buttons button:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <nav class="navigation-menu">
            <ul>
                <li><a href="http://localhost/hexass/vocab.php">Vocabulary Lessons</a></li>
                <li><a href="http://localhost/hexass/speech.php">Speech Lessons</a></li>
                <li><a href="http://localhost/hexass/pronon.php">Pronunciation Lessons</a></li>
                <li><a href="http://localhost/hexass/test.php">Practice Tests</a></li>
                
            </ul>
        </nav>

        
        <main class="main-content">
            
            <div class="welcome-message">
                <h1>Welcome To Soft Skills Learning..!! </h1>
                <p>A result-driven business dedicated to helping client achieve their goals....!!</p>
            </div>

            
            <div class="quick-access">
                <h2>About the content</h2>
                <p>The purpose of Soft Skill Learning is for developing an English Efficiency specifically designed for new recruits in a company.
                 This app aims to enhance their vocabulary, speech, and pronunciation skills through interactive lessons, practice tests, and detailed test reports.
                The learning path will be customized to meet the needs of the HR department for employee development.</p>
            </div>
        </main>
    </div>
</body>
</html>
