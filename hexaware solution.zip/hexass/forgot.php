<!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>forgot password</title>
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body{
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-image: url(images/bg3.jpeg);
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center;

        }
        .wrapper{
            width: 420px;
            background: transparent;
            border: 2px solid rgba(255,255,255,.2);
            backdrop-filter: blur(20px);
            box-shadow: 0 0 10px rgba(0,0,0,.2);
            color: white;
            border-radius: 10px;
            padding: 30px 40px;

        }
        .wrapper h1{
            font-size: 36px;
            text-align: center;
        }
        .wrapper .input-box{
            width: 100%;
            height: 50px;
            margin: 30px 0;
            position: relative;
        }
        .input-box input{
            width: 100%;
            height: 100%;
            background: transparent;
            border: none;
            outline: none;
            border: 2px solid rgba(255,255,255,.2);
            border-radius: 40px;
            font-size: 16px;
            color: white;
            padding: 20px 45px 20px 20px;
        }
        .input-box input::placeholder{
            color: white;
        }
        .input-box i{
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
        }
        .wrapper .remember-forgot{
            display: flex;
            justify-content: space-between;
            font-size: 14.5px;
            margin: -15px 0 15px;
        }
        .remember-forgot label input{
            accent-color: white;
            margin-right: 3px;
        }
        .remember-forgot a{
            color: white;
            text-decoration: none;
        }
        .remember-forgot a:hover{
            text-decoration: underline;   
        }
        .wrapper .btn{
            width: 100%;
            height: 45px;
            background: white;
            border: none;
            outline: none;
            border-radius: 40px;
            box-shadow: 0 0 10px rgba(0,0,0,.1);
            cursor: pointer;
            font-size: 16px;
            color: #333;
            font-weight: 600;
        }
        .wrapper .login-link{
            font-size: 14.5px;
            text-align: center;
            margin: 20px 0 15px;
        }
        .login-link p a{
            color: white;
            text-decoration: none;
            font-weight: 600;
        }
        .login-link p a:hover{
            text-decoration: underline;

        }
        .wrapper .recovery-link{
            font-size: 14.5px;
            text-align: center;
            margin: 20px 0 15px;
        }
        .recovery-link p a{
            color: white;
            text-decoration: none;
            font-weight: 600;
        }
        .recovery-link p a:hover{
            text-decoration: underline;

        }
    </style>
</head>
<body>
<div class="wrapper">
        <form action="">
            <h1>Forgot Password</h1>
            
            <div class="input-box">
                <input type="password" placeholder=" New password " maxlength="8" required>
                <i class='bx bxs-lock-alt'></i>
            </div>
            <div class="input-box">
                <input type="password" placeholder="Re-enter your Password" maxlength="8" required>
                <i class='bx bxs-lock-alt'></i>
            </div>
            <button type="submit" class="btn">Reset</button>  

            <div class="login-link">
                <p>Back to login?  <a href="http://localhost/hexass/login1.php"> Login</a></p>
            </div>     
            <div class="recovery-link">
                <p>To recover old password?<a href="http://localhost/hexass/recover.php">Recover</a></p>
            </div>     
        </form>
    </div>
</body>